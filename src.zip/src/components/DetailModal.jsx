const DetailModal = ({ data, onClose }) => {
  if (!data) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center p-4">
      <div className="bg-white max-w-3xl w-full p-6 rounded-xl overflow-y-auto max-h-[90vh]">

        <button onClick={onClose} className="mb-4 text-red-500">
          Close
        </button>

        {/* Trip Summary */}
        <h2 className="text-2xl font-bold mb-2">
          {data.trip_summary.title}
        </h2>

        <p className="text-gray-600 mb-4">
          {data.trip_summary.destinations.join(", ")}
        </p>

        {/* Daily Itinerary */}
        <h3 className="font-semibold mt-4">Itinerary</h3>

        {data.daily_itinerary?.map((day) => (
          <div key={day.day_index} className="mt-3 border p-3 rounded">
            <p className="font-semibold">
              Day {day.day_index} - {day.title}
            </p>

            {day.activities.map((act) => (
              <p key={act.id} className="text-sm text-gray-600">
                • {act.name} ({act.start} - {act.end})
              </p>
            ))}
          </div>
        ))}

        {/* Budget */}
        <h3 className="font-semibold mt-4">Budget</h3>
        <p>
          Total: {data.trip_summary.total_estimated_cost.amount}{" "}
          {data.trip_summary.total_estimated_cost.currency}
        </p>

        {/* Tips */}
        <h3 className="font-semibold mt-4">Tips</h3>
        <ul className="list-disc ml-5">
          {data.safety_and_local_tips?.map((tip, i) => (
            <li key={i}>{tip}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default DetailModal;