const History = ({ items, onSelect }) => {
    if (!Array.isArray(items)) return null;

    return (
        <div className="mt-6">
            <h3 className="font-semibold mb-2">Previous Queries</h3>

            <div className="space-y-2">
                {items.map((item) => (
                    <div
                        key={item._id}
                        onClick={() => onSelect(item.response)}
                        className="p-3 border rounded-lg text-sm bg-gray-50 cursor-pointer 
                                hover:bg-gray-100 transition-all duration-200 
                                hover:shadow-md hover:scale-[1.02]"
                     >
                        {item.query}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default History;