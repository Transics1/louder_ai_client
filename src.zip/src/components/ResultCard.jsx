const ResultCard = ({ data, onClick }) => {
  if (!data) return null;

  const summary = data.trip_summary;

  return (
    <div
      onClick={() => onClick(data)}
      className="bg-white p-5 rounded-xl shadow mt-6 cursor-pointer
                 hover:shadow-lg transition"
    >
      <h2 className="text-xl font-bold">
        {summary?.title || "Trip Plan"}
      </h2>

      <p className="text-gray-500">
         {summary?.destinations?.join(", ")}
      </p>

      <p className="mt-2 font-semibold">
         {summary?.total_estimated_cost?.amount} {summary?.total_estimated_cost?.currency}
      </p>

      <p className="mt-3 text-gray-600">
        {summary?.variant} plan for {summary?.num_travelers} travelers
      </p>
    </div>
  );
};

export default ResultCard;