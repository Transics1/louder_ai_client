import { useState, useEffect } from "react";
import api from "../api/axios";
import ResultCard from "../components/ResultCard";
import History from "../components/History";
import DetailModal from "../components/detailModal";

const Home = () => {
    const [query, setQuery] = useState("");
    const [result, setResult] = useState(null);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedDetail, setSelectedDetail] = useState(null);

    const fetchHistory = async () => {
        try {
            const res = await api.get("/events/my");
            setHistory(res.data.data);
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => {
        fetchHistory();
    }, []);

    const handleGenerate = async () => {
        if (!query) return;

        try {
            setLoading(true);

            const res = await api.post("/events/generate", { query });

            setResult(res.data.data.response); // full object
            fetchHistory();
        } catch (err) {
            alert("Error generating event");
        } finally {
            setLoading(false);
        }
    };

    const logout = () => {
        localStorage.removeItem("token");
        window.location.href = "/login";
    };

    return (
        <div className="min-h-screen bg-gray-100 p-6">
            <div className="max-w-3xl mx-auto">

                {/* Navbar */}
                <div className="flex justify-between mb-6">
                    <h1 className="text-2xl font-bold">Louder AI ✨</h1>
                    <button onClick={logout} className="text-red-500">
                        Logout
                    </button>
                </div>

                {/* Input */}
                <div className="bg-white p-4 rounded-xl shadow">
                    <input
                        className="w-full p-3 border rounded mb-3 
                            focus:outline-none focus:ring-2 focus:ring-black"
                        placeholder="Describe your event or trip..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />

                    <button
                        onClick={handleGenerate}
                        className="bg-black text-white px-4 py-2 rounded w-full
             transition-all duration-200
             hover:bg-gray-800 hover:scale-[1.01]"
                    >
                        {loading ? "AI is planning..." : "Generate"}
                    </button>
                </div>

                {/* Result */}
                <ResultCard data={result} onClick={setSelectedDetail} />

                {/* History */}
                <History items={history} onSelect={setSelectedDetail} />

                <DetailModal
                    data={selectedDetail}
                    onClose={() => setSelectedDetail(null)}
                />

            </div>
        </div>
    );
};

export default Home;